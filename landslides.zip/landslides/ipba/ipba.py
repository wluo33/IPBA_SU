import numpy as np
from .drainage_basins import DrainageBasins

def IPBA(lattice, arr, sinks):
    # setting the lattice
    lattice.SetLattice(arr)

    # defining the sigma
    for k in range(lattice.n):
        x = lattice.sites[k]
        if np.isnan(x.prob):
            x.isnum = False

    # defining the sink
    for k, v in sinks.items():
        x = lattice.sites[k]
        
        x.sink = v
    
    # performing the DrainageBasins
    DrainageBasins(lattice)