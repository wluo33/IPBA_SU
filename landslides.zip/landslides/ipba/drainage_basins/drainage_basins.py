from .invasion_percolation import InvasionPercolation

def DrainageBasins(lattice):
    for k in range(lattice.n):
        x = lattice.sites[k]
        InvasionPercolation(lattice, x)