from heap.heap import Heap

def InvasionPercolation(lattice, x):
    if x.isnum and x.sigma is None:
        for y in lattice.burnt:
            y.status = None
        lattice.burnt = []
        heap = Heap()
        
        lattice.burnt.append(x)
        x.status = False
        parent = x
        
        heap.Insert(x.prob, x.k)

        stop = False
        while heap.m > 0 and stop == False:
            _, t = heap.ExtractMin()
            
            y = lattice.sites[t]

            y.status = True
            y.parent = parent
            parent = y
            
            if y.sigma is not None:
                w = y.sigma
                stop = True
            
            if y.sink is not None:
                w = y.k
                stop = True
            
            if stop == False:
                for z in lattice.GetSiteNeighbors(y):
                    if z.isnum and z.status is None:
                        lattice.burnt.append(z)
                        z.status = False
                        
                        heap.Insert(z.prob, z.k)
        
        if stop:
            while y.parent != y:
                y.sigma = w
                z = lattice.sites[w]
                y.label = z.sink
                
                y = y.parent
            
            y.sigma = w
            z = lattice.sites[w]
            y.label = z.sink