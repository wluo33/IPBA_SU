# python3 main.py belm_crop b_strlnk binv_strlnk4 0.90 0.95 0.99 42 p0.90_p0.95_p0.99_s42 T
import sys
import numpy as np

from geotiff import ReadGeoTiff, WriteGeoTiff, WriteShapeFile
from lattice import Lattice
from ipba import IPBA

# PARAMETERS
filename0 = sys.argv[1]
filename1 = sys.argv[2]
filename2 = sys.argv[3]
p0 = float(sys.argv[4])
p1 = float(sys.argv[5])
p2 = float(sys.argv[6])
seed = int(sys.argv[7])
filename = sys.argv[8]
flag = sys.argv[9] == 'T'

np.random.seed(seed)
epsilon = 1 / 1000
# PARAMETERS

# INPUT
info, tiff = ReadGeoTiff(r'datasets/{}'.format(filename0)) # float array
nrows = info['RasterYSize'] + 2
ncols = info['RasterXSize'] + 2
nodata = info['NoDataValue']

tiff = np.where(np.isclose(tiff, info['NoDataValue']),
                np.nan,
                tiff)

tiff += epsilon * np.random.random(tiff.shape)

arr = np.full((nrows, ncols), np.nan, dtype = np.float32)
arr[1 : nrows - 1, 1 : ncols - 1] = tiff
# INPUT

# INPUT
info1, tiff1 = ReadGeoTiff(r'datasets/{}'.format(filename1)) # int array

sinks1 = {}
for j in range(info1['RasterYSize']):
    for i in range(info1['RasterXSize']):
        if tiff1[j, i] > 0 and tiff1[j, i] != info1['NoDataValue']:
            k = (i + 1) + (j + 1) * ncols

            sinks1[k] = tiff1[j, i]
# INPUT

# INPUT
info2, tiff2 = ReadGeoTiff(r'datasets/{}'.format(filename2)) # int array

sinks2 = {}
for j in range(info2['RasterYSize']):
    for i in range(info2['RasterXSize']):
        if tiff2[j, i] > 0 and tiff2[j, i] != info2['NoDataValue']:
            k = (i + 1) + (j + 1) * ncols

            sinks2[k] = tiff2[j, i]
# INPUT

lattice = Lattice(nrows, ncols)

# WATERSHEDS
IPBA(lattice, arr.flatten(), sinks1)

basins = lattice.GetBasins(p0)
new_sinks = {}
for k, v in sinks1.items():
    if v in basins:
        new_sinks[k] = v

IPBA(lattice, arr.flatten(), new_sinks)
lattice.SetLabels(0)
# WATERSHEDS

# OUTPUT
if flag:
    WriteGeoTiff(info,
                lattice.label[0, 1:lattice.nrows - 1, 1:lattice.ncols - 1],
                'results/{}_0_{}'.format(filename0, filename))

    WriteShapeFile('results/{}_0_{}'.format(filename0, filename))
# OUTPUT

# INVERTED WATERSHEDS
IPBA(lattice, -arr.flatten(), sinks2)

basins = lattice.GetBasins(p1)
new_sinks = {}
for k, v in sinks2.items():
    if v in basins:
        new_sinks[k] = v

IPBA(lattice, -arr.flatten(), new_sinks)
lattice.SetLabels(1)
# INVERTED WATERSHEDS

# OUTPUT
if flag:
    WriteGeoTiff(info,
                lattice.label[1, 1:lattice.nrows - 1, 1:lattice.ncols - 1],
                'results/{}_1_{}'.format(filename0, filename))

    WriteShapeFile('results/{}_1_{}'.format(filename0, filename))
# OUTPUT

# MERGING LABELS
lattice.MergeLabels(p2)
# MERGING LABELSe

# OUTPUT
WriteGeoTiff(info,
             lattice.new_label[1:lattice.nrows - 1, 1:lattice.ncols - 1],
             'results/{}_{}'.format(filename0, filename))

WriteShapeFile('results/{}_{}'.format(filename0, filename))
# OUTPUT