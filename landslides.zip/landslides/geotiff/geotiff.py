from osgeo import gdal, osr, ogr
import numpy as np

def ReadGeoTiff(filename):
    raster = gdal.Open(r'{}.tif'.format(filename))
    
    info = {}
    info['RasterYSize'] = raster.RasterYSize
    info['RasterXSize'] = raster.RasterXSize
    info['GeoTransform'] = raster.GetGeoTransform()
    info['Projection'] = raster.GetProjection()
    
    band = raster.GetRasterBand(1)
    info['NoDataValue'] = band.GetNoDataValue()
    arr = band.ReadAsArray()
    
    del band
    del raster

    return info, arr

def WriteGeoTiff(info, arr, filename):
    nrows, ncols = arr.shape
    d = {}
    for j in range(nrows):
        for i in range(ncols):
            if arr[j, i] in d:
                d[arr[j, i]].append((j, i))
            else:
                d[arr[j, i]] = [(j, i)]
    
    n = len(d)
    keys = sorted(d.keys())
    
    arr_tiff = np.zeros((nrows, ncols), dtype = np.uint16)
    for t, k in enumerate(keys):
        for j, i in d[k]:
            arr_tiff[j, i] = t
    
    driver = gdal.GetDriverByName('GTiff')
    raster = driver.Create(r'{}.tif'.format(filename),
                           info['RasterXSize'],
                           info['RasterYSize'],
                           1,
                           gdal.GDT_UInt16)
    
    raster.SetGeoTransform(info['GeoTransform'])
    raster.SetProjection(info['Projection'])
    
    colors = [(0.0, 0.0, 0.0)] + [(0.2 + 0.6 * np.random.random(),
                                   0.2 + 0.6 * np.random.random(),
                                   0.2 + 0.6 * np.random.random()) for i in range(n - 1)]
    
    raster.GetRasterBand(1).SetNoDataValue(0)
    raster.GetRasterBand(1).WriteArray(arr_tiff)
    
    band = raster.GetRasterBand(1)
    color_table = gdal.ColorTable()
    
    for i, color in enumerate(colors):
        color_table.SetColorEntry(i, (int(255 * color[0]),
                                      int(255 * color[1]),
                                      int(255 * color[2])))
    
    band.SetRasterColorTable(color_table)
    band.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
    
    raster.FlushCache()
    
    del band
    del raster

def WriteShapeFile(filename):
    raster = gdal.Open(r'{}.tif'.format(filename))
    
    srs = osr.SpatialReference()
    srs.ImportFromWkt(raster.GetProjection())

    band = raster.GetRasterBand(1)

    driver = ogr.GetDriverByName('ESRI Shapefile')
    shapefile = driver.CreateDataSource(r'{}.shp'.format(filename))
    layer = shapefile.CreateLayer('polygons',
                                  srs = srs)
    
    field = ogr.FieldDefn('ID',
                          ogr.OFTInteger)
    
    layer.CreateField(field)

    gdal.Polygonize(band,
                    band.GetMaskBand(),
                    layer,
                    0,
                    [],
                    callback = None)
    
    del layer
    del shapefile
    del band
    del raster