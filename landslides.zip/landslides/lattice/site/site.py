class Site:
    def __init__(self, k, prob):
        self.k = k
        self.prob = prob
        self.isnum = True
        self.sink = None
        self.sigma = None
        
        self.status = None
        self.parent = self
        self.label = None