import numpy as np
from .site import Site

class Lattice:
    def __init__(self, nrows, ncols):
        self.nrows = nrows
        self.ncols = ncols
        self.n = self.nrows * self.ncols
        
        self.sites = np.empty(self.n, dtype = Site)

        self.burnt = []
        self.label = - np.ones((2, self.nrows, self.ncols), dtype = np.int64)
        self.new_label = -np.ones((self.nrows, self.ncols), dtype = np.int64)
    
    def SetLattice(self, arr):
        for k in range(self.n):
            self.sites[k] = Site(k, arr[k])
    
    def GetSiteNeighbors(self, x):
        neighbors = (self.sites[x.k + 1],
                     self.sites[x.k - self.ncols],
                     self.sites[x.k - 1],
                     self.sites[x.k + self.ncols])
        return neighbors
    
    def GetBasins(self, p = None):
        areas = {}
        for k in range(self.n):
            x = self.sites[k]
            if x.label is not None:
                if x.label in areas:
                    areas[x.label] += 1
                else:
                    areas[x.label] = 1
        
        ordered_areas = sorted(areas.items(),
                               key = lambda x: x[1],
                               reverse = True)

        labels, counts = np.asarray(list(zip(*ordered_areas)))

        if p is None:
            basins = labels
        else:
            indexes = np.argwhere(np.cumsum(counts) / np.sum(counts) <= p)
            filtered_indexes = np.squeeze(indexes,
                                          axis = 1)
            
            basins = labels[filtered_indexes]
        
        return basins
    
    def SetLabels(self, idx):
        for j in range(1, self.nrows - 1):
            for i in range(1, self.ncols - 1):
                k = i + j * self.ncols
                x = self.sites[k]
                if x.label is not None:
                    self.label[idx, j, i] = x.label
    
    def MergeLabels(self, p = None):
        for j in range(self.nrows):
            for i in range(self.ncols):
                a = self.label[0, j, i]
                b = self.label[1, j, i]

                if a >= 0 and b >= 0:
                    self.new_label[j, i] = int(0.5 * (a + b) * (a + b + 1) + b) # Cantor paring function
                else:
                    self.new_label[j, i] = -1
        
        labels, counts = np.unique(self.new_label,
                                   return_counts = True)
        
        indexes = np.argsort(counts)[::-1]
        counts = counts[indexes]
        labels = labels[indexes]
        
        if p is None:
            slope_units = labels
        else:
            indexes = np.argwhere(np.cumsum(counts) / np.sum(counts) <= p)
            filtered_indexes = np.squeeze(indexes,
                                          axis = 1)
            
            slope_units = labels[filtered_indexes]
        
        for j in range(self.nrows):
            for i in range(self.ncols):
                if self.new_label[j, i] not in slope_units:
                    self.new_label[j, i] = -1