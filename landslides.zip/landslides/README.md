# Invasion Percolation Based Algorithm for Landslides
